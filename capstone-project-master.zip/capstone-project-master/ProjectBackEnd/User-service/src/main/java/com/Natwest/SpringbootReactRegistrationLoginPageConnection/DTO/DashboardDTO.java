//package com.Natwest.SpringbootReactRegistrationLoginPageConnection.DTO;
//
//public class DashboardData {
//    private User user;
//    private List<Loan> loans;
//
//    public DashboardData(User user, List<Loan> loans) {
//        this.user = user;
//        this.loans = loans;
//    }
//
//    // Getters and setters for user and loans
//
//    // Additional methods or fields as needed
//}
