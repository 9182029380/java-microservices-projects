package com.example.Natwest.CardService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CardServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
