package com.example.capston;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CapstonApplicationTests {

	@Test
	void contextLoads() {
	}

}
