import React from 'react'

export default function Offer() {
  return (
    <div></div>
  )
}
