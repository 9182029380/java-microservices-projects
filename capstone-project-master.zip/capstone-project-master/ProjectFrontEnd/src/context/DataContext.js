import { createContext, useEffect, useState } from "react";

const DataContext = createContext({});
