package com.Capstone.Insurance.Exceptions;

public class PolicyAlreadyExistsException extends Exception {
    public PolicyAlreadyExistsException(String message) {
            super(message);
        }

}
