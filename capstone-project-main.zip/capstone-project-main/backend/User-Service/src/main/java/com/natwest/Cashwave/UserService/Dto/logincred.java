package com.natwest.Cashwave.UserService.Dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class logincred {
    private String emailid;
    private String security_PIN;


}
