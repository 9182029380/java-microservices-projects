import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css';
import LandingPage from '../LandingPage/LandingPage';
import '../script.css';

const Home = () => {
    // return <div><Login></Login></div>;
    return <div className="voilet-bg"><LandingPage/></div>
}
 
export default Home;