package com.Natwest.project.budgeting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BudgetingApplicationTests {

	@Test
	void contextLoads() {
	}

}
