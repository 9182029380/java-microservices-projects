package com.Natwest.project.esg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EsgApplicationTests {

	@Test
	void contextLoads() {
	}

}
